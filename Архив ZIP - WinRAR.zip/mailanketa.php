<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    // Добавьте обработку других полей анкеты

    // Адрес, на который нужно отправить анкету
    $to = "your-email@example.com";

    // Тема письма
    $subject = "Новая анкета от $name";

    // Содержание письма
    $message = "Имя: $name\n";
    $message .= "Email: $email\n";
    // Добавьте содержание для других полей анкеты

    // Обработка загруженного файла
    $file_name = $_FILES["file"]["name"];
    $file_tmp = $_FILES["file"]["tmp_name"];
    $file_type = $_FILES["file"]["type"];
    $file_size = $_FILES["file"]["size"];

    // Переместите загруженный файл в указанную директорию (в данном случае, текущая директория)
    move_uploaded_file($file_tmp, $file_name);

    // Добавьте информацию о файле в содержание письма
    $message .= "Прикрепленный файл: $file_name";

    // Отправка письма
    $headers = "From: $email";

    // Определите Content-Type для включения вложения
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"boundary\"\r\n";

    // Создание тела письма
    $body = "--boundary\r\n";
    $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
    $body .= $message . "\r\n";
    $body .= "--boundary\r\n";
    $body .= "Content-Type: application/octet-stream; name=\"$file_name\"\r\n";
    $body .= "Content-Transfer-Encoding: base64\r\n";
    $body .= "Content-Disposition: attachment; filename=\"$file_name\"\r\n\r\n";
    $body .= chunk_split(base64_encode(file_get_contents($file_name))) . "\r\n";
    $body .= "--boundary--";

    mail($to, $subject, $body, $headers);

    // Перенаправление пользователя после отправки анкеты
    header("Location: success.html");
} else {
    // Если запрос не является POST, перенаправьте на страницу с формой
    header("Location: form.html");
}
?>