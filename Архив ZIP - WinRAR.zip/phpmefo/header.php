<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container"><!--aya entertainment & cuisine hub-->
			<a class="navbar-brand" href="index.php"><img  src="images/logo.png" alt="logo"></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="oi oi-menu"></span> Menu
			</button>

			<div class="collapse navbar-collapse" id="ftco-nav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item active"><a href="index.php" class="nav-link active-item">Главная</a></li>
					<li class="nav-item"><a href="about.php" class="nav-link">О нас</a></li>
					<li class="nav-item"><a href="destination.php" class="nav-link">Портфолио</a></li>
					<li class="nav-item"><a href="hotel.php" class="nav-link">Услуги</a></li>
					<li class="nav-item"><a href="blog.php" class="nav-link">Блог</a></li>
					<li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!-- END nav -->