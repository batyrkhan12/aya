<footer class="ftco-footer bg-bottom ftco-no-pt" style="background-image: url(images/bg_3.jpg);">
			<div class="container">
				<div class="row mb-5">
					<div class="col-md pt-5">
						<div class="ftco-footer-widget pt-md-5 mb-4">
							<h2 class="ftco-heading-2">Социальные сети	</h2>
							<!--<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>-->
							<ul class="ftco-footer-social list-unstyled float-md-left float-left">
								<!--<li class="ftco-animate"><a href="#"><span class="fa fa-twitter"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="fa fa-facebook"></span></a></li>-->
								<li class="ftco-animate">Hazbin art space<a href="https://www.instagram.com/hazbin_alm/"><span class="fa fa-instagram"></span></a></li>
								<li class="ftco-animate">Goose Restaurant<a href="https://www.instagram.com/goose.almaty/"><span class="fa fa-instagram"></span></a></li>
								<li class="ftco-animate">Coffe milka<a href="https://www.instagram.com/coffeemilkaa/"><span class="fa fa-instagram"></span></a></li>
								<li class="ftco-animate">Luna Terrace<a href="https://www.instagram.com/luna__terrace/"><span class="fa fa-instagram"></span></a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-md pt-5 border-left">
						<div class="ftco-footer-widget pt-md-5 mb-4 ml-md-5">
							<h2 class="ftco-heading-2">Infromation</h2>

						</div>
					</div>
					<!--<div class="col-md pt-5 border-left">
						<div class="ftco-footer-widget pt-md-5 mb-4">
							<h2 class="ftco-heading-2">Experience</h2>
							<ul class="list-unstyled">
								<li><a href="#" class="py-2 d-block">Adventure</a></li>
								<li><a href="#" class="py-2 d-block">Hotel and Restaurant</a></li>
								<li><a href="#" class="py-2 d-block">Beach</a></li>
								<li><a href="#" class="py-2 d-block">Nature</a></li>
								<li><a href="#" class="py-2 d-block">Camping</a></li>
								<li><a href="#" class="py-2 d-block">Party</a></li>
							</ul>
						</div>
					</div>-->
					<div class="col-md pt-5 border-left">
						<div class="ftco-footer-widget pt-md-5 mb-4">
							<h2 class="ftco-heading-2">Have a Questions?</h2>
							<div class="block-23 mb-3">
								<ul>
									<li><span class="icon fa fa-map-marker"></span><span class="text">Алматы қаласы Бостандық ауданы Байтурсынова 141 Қазақстан Республикасы</span></li>
									<li><a href="#"><span class="icon fa fa-phone"></span><span class="text">+7 777 211 84 40</span></a></li>
									<li><a href="#"><span class="icon fa fa-envelope-o"></span><span class="text">aya.almatyrest@gmail.com</span></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 text-center">

						<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
						</div>
					</div>
				</div>
			</footer>