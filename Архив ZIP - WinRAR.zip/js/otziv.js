// Обработчик события отправки формы
function handleSubmit(event) {
    // Прерываем стандартную обработку формы
    event.preventDefault();
  
    // Получаем данные из формы
    const name = document.getElementById("name").value;
    const rating = document.getElementById("rating").value;
    const review = document.getElementById("review").value;
  
    // Отправляем данные на сервер
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "index.php");
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(`name=${name}&rating=${rating}&review=${review}`);
  }
  
  // Прикрепляем обработчик события к форме
  document.getElementById("form").addEventListener("submit", handleSubmit);



  function rateStar(event) {
    const stars = document.querySelectorAll('.star');
    const clickedStar = event.target;
  
    stars.forEach(star => {
      star.classList.remove('active');
    });
  
    clickedStar.classList.add('active');
  
    const ratingValue = clickedStar.getAttribute('data-value');
    // Добавьте здесь логику для обработки выбранной звезды, например, отправка на сервер или сохранение локально.
    console.log('Выбрана звезда с рейтингом ' + ratingValue);
  }