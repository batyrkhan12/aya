<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pacific - Free Bootstrap 4 Template by Colorlib</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Arizonia&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="css/animate.css">
  
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">

  
  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

	<?php 
	 	require "phpmefo/header.php"
	?>
 <!-- END nav -->
 
 <section class="ftco-section services-section">
  <div class="container">
    <div class="row d-flex">
      <div class="col-md-6 order-md-last heading-section pl-md-5 ftco-animate d-flex align-items-center">
        <div class="w-100">
          <span class="subheading"><img  src="images/logo.png" alt="logo"></span>
          
          <p>Aya Entertainment & Cuisine Hub предлагает высококлассные рестораны, разнообразные развлечения и культурные мероприятия. Мы специализируемся на предоставлении высококачественного ресторанного обслуживания и организации уникальных ивент-площадок. Кроме того, наши услуги включают техническое обслуживание и оборудование для шоу.

Инновационный подход и профессионализм нашей команды помогут нам вместе создать неповторимую атмосферу и незабываемые впечатления для наших клиентов.

Мы стремимся быть лучшими в своей отрасли и всегда открыты для сотрудничества с новыми клиентами и партнерами. Мы готовы предложить уникальные решения, чтобы ваше мероприятие стало особым и продолжим радовать наших гостей высоким уровнем сервиса и уникальной атмосферой.</p>
          
        </div>
      </div>
      <div class="col-md-6">
        <div class="row">

        </div>
      </div>
    </div>
  </div>
</section>


<section class="ftco-section ftco-about img"style="background-image: url(images/bg_4.jpg);">
 <div class="overlay"></div>
 <div class="container py-md-5">
  <div class="row py-md-5">
   <div class="col-md d-flex align-items-center justify-content-center">
    <a href="https://vimeo.com/45830194" class="icon-video popup-vimeo d-flex align-items-center justify-content-center mb-4">
     <span class="fa fa-play"></span>
   </a>
 </div>
</div>
</div>
</section>

<section class="ftco-section ftco-about ftco-no-pt img">
 <div class="container">
  <div class="row d-flex">
   <div class="col-md-12 about-intro">
    <div class="row">
     <div class="col-md-6 d-flex align-items-stretch">
      <div class="img d-flex w-100 align-items-center justify-content-center" style="background-image:url(images/about-1.jpg);">
      </div>
    </div>
    <div class="col-md-6 pl-md-5 py-5">
      <div class="row justify-content-start pb-3">
        <div class="col-md-12 heading-section ftco-animate">
         <!--<span class="subheading">About Us</span>
         <h2 class="mb-4">Make Your Tour Memorable and Safe With Us</h2>
         <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
         <p><a href="#" class="btn btn-primary">Book Your Destination</a></p>-->
       </div>
     </div>
   </div>
 </div>
</div>
</div>
</div>
</section>

<section class="ftco-section testimony-section bg-bottom" style="background-image: url(images/bg_1.jpg);">
  <div class="overlay"></div>
  <div class="container">
    <div class="row justify-content-center pb-4">
      <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
        <!--<span class="subheading">Testimonial</span>-->
        <h2 class="mb-4">Оставить отзыв</h2>
      </div>
    </div>
    <div class="row ftco-animate">
      <div class="col-md-12">
        <div class="block-12">
  
          <form action="#" class="bg-light p-5 contact-form">
          <div class="stars-container">
          <p class="star mb-2">
            <span data-value="1" class="fa fa-star"></span>
            <span data-value="2" class="fa fa-star"></span>
            <span data-value="3" class="fa fa-star"></span>
            <span data-value="4" class="fa fa-star"></span>
            <span data-value="5" class="fa fa-star"></span>
            <span data-value="6" class="fa fa-star"></span>
            <span data-value="7" class="fa fa-star"></span>
            <span data-value="7" class="fa fa-star"></span>
            <span data-value="7" class="fa fa-star"></span>
            <span data-value="7" class="fa fa-star"></span>
          </p>
            <div class="form-group">
            <input type="text" class="form-control" placeholder="Your Name">
            </div>
            <div class="form-group">
            <input type="text" class="form-control" placeholder="Your Email">
            </div>
            <div class="form-group">
            <textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="review"></textarea>
            </div>
            <div class="form-group">
            <input type="submit" value="Send Message" class="btn btn-primary py-3 px-5">
            </div>
          </form>
         </div>
        <!--<div class="carousel-testimony owl-carousel">

        </div>-->
      </div>

    </div>
  </div>
</section>

<section class="ftco-intro ftco-section ftco-no-pt">
 <div class="container">
  <div class="row justify-content-center">
   <div class="col-md-12 text-center">
    <div class="img"  style="background-image: url(images/bg_2.jpg);">
     <div class="overlay"></div>
     <h2>We Are Pacific A Travel Agency</h2>
     <p>We can manage your dream building A small river named Duden flows by their place</p>
     <p class="mb-0"><a href="#" class="btn btn-primary px-4 py-3">Ask For A Quote</a></p>
   </div>
 </div>
</div>
</div>
</section>

<?php 
  require 'phpmefo/footer.php'
?>



<!-- loader -->
<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="js/google-map.js"></script>
<script src="js/main.js"></script>

</body>
</html>