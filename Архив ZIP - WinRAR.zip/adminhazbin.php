<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Бронирование столика</title>
</head>
<body>

<form action="process_booking.php" method="post">
    <label for="name">Имя:</label>
    <input type="text" id="name" name="name" required>

    <label for="date">Дата:</label>
    <input type="date" id="date" name="date" required>

    <label for="time">Время:</label>
    <input type="time" id="time" name="time" required>

    <button type="submit">Забронировать</button>
</form>

</body>
</html>
